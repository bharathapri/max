#tap on this button to scan qr code
[![Run on Repl.it](https://repl.it/badge/github/quiec/whatsAlfa)](https://replit.com/@kavishkaya/lusifarqr)



#tap this to deploy bot
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/bharathapriyanath/max)
     </div>
